Polygons: Cliff + Hole: 100m high cliff, 70x70m hole, 5m in the cliff
Density: 0.1, 1, 10, 100, 1000
Distance to the cliff: 20 m
Sensor size: 0.05 m
Distance between sensors: 0.2m
