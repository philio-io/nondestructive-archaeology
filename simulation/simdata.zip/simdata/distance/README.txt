Polygons: Cliff + Hole: 100m high cliff, 70x70m hole, 5m in the cliff
Density: 1.57
Distance to the cliff: 10, 20, 60, 100, 150, 200m
Sensor size: 0.05 m
Distance between sensors: 0.2m
