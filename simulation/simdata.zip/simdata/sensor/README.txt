Polygons: Cliff + Hole: 100m high cliff, 70x70m hole, 5m in the cliff
Density: 1.57
Distance to the cliff: 20 m
Sensor size: 0.05 m
Distance between sensors: 0.04, 0.1, 0.2, 0.3, 1 m
