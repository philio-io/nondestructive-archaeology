Polygons: 
	Cube: 25x25m, 50m above the ground
	Cliff: 100m high
	Cliff + Hole: 100m high cliff, 70x70m hole, 5m in the cliff
	Earth: Nothing above horizon
	Pyramid: triangle (0, 0), (100, 100), (200, 100)
	Hollow Pyramid: same as pyramid, but 2m walls
Distance to the cliff: 20 m
Sensor size: 0.05 m
Distance between sensors: 0.2m
